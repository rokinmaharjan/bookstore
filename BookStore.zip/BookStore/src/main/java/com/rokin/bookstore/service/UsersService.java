package com.rokin.bookstore.service;

import com.rokin.bookstore.entity.Users;

public interface UsersService {

		public Users addUser(Users user);
	
}
