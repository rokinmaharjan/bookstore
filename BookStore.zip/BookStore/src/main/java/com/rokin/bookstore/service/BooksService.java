package com.rokin.bookstore.service;

import java.util.List;

import com.rokin.bookstore.entity.Books;

public interface BooksService {
	public List<Books> getAllBooks();
}
